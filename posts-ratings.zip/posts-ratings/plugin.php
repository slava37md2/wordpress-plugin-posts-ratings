<?php
/*
Plugin Name: post-ratings
Plugin URI: https://rimir.com.ua/wp/2017/09/13/wordpress-webcam-comments-plugin-page/
Description: Attach rating to posts.
Version: 1.0.1
Author: Deorditsa Veaceslav
Author URI: https://rimir.com.ua/wp/2017/09/13/wordpress-webcam-comments-plugin-page/
Disclaimer: Use at your own risk. No warranty expressed or implied is provided.
*/

/*
    Copyright 2017 Deorditsa Veacheslav

*/




add_filter( 'the_content', 'my_the_content_filter' );
function my_the_content_filter($content) {
	global $wpdb;
	$id = get_the_ID();
	$row = $wpdb->get_row( "SELECT * FROM $wpdb->posts WHERE ID=$id" );
	$rating = $row->pluses - $row->minuses;
	
	if( $rating > 0 ){$rating='+'.$rating;$color='green';}
	if( $rating < 0 ){$color='red';}
	
	$content .= 'Оцените запись без регистрации: .. <span id="strelka_vverh_posts'.$id.'" style="display: inline-block"><a href="javascript:void(0);" onclick="ajax_plus_ili_minus(1,'.$id.');"><img src="'.
	site_url().'/wp-content/plugins/comment-ratings/strelka_up.jpg"></a></span> <span id="rating'.$id.'" style="color: '.$color.'" title="Общий рейтинг '.
	$rating.': &uarr;'.$row->pluses.' и &darr;'.$rating = $row->minuses.'">'.
	$rating.'</span> . <span id="strelka_vniz_posts'.$id.'" style="display: inline-block"><a href="javascript:void(0);" onclick="ajax_plus_ili_minus(-1,'.$id.');"><img src="'.site_url().'/wp-content/plugins/comment-ratings/strelka_down.jpg"></a></span><br>';

	return $content;
}









add_action( 'wp_print_footer_scripts', 'hook_javascript' );
function hook_javascript(){
	?>
<script type='text/javascript'> 
function ajax_plus_ili_minus( plus_ili_minus, post_id ){

	var xhr = new XMLHttpRequest();
	xhr.open('GET', "<?php echo site_url();?>/wp-content/plugins/posts-ratings/save-rating-vote.php?pilim="+plus_ili_minus+'&post_id='+post_id, true);
	xhr.send();
	xhr.onreadystatechange = function() {
		if (this.readyState != 4) return;

  // по окончании запроса доступны:
  // status, statusText
  // responseText, responseXML (при content-type: text/xml)

		if (this.status != 200) {
    // обработать ошибку
			alert( 'ошибка: ' + (this.status ? this.statusText : 'запрос не удался') );
			return;
		}
		else //(this.status == 200) 
		{
    // получить результат из this.responseText или this.responseXML
			//alert( this.responseText );
			remove_arrows_posts(post_id);//убираем стрелки
			
			if(plus_ili_minus==1)document.getElementById('rating'+post_id).innerHTML = parseInt(document.getElementById('rating'+post_id).innerHTML, 10)+1;// изменяем рейтинг
			if(plus_ili_minus==-1)document.getElementById('rating'+post_id).innerHTML = parseInt(document.getElementById('rating'+post_id).innerHTML, 10)-1;
			
			localStorage.setItem("post"+post_id, Date.now());//сохраняем в localStorage номер комментария и дату и время голосования в миллисекундах с 1970 года
			all_id_voted_posts = localStorage.getItem("all_id_voted_posts");
			localStorage.setItem("all_id_voted_posts",all_id_voted_posts+" "+post_id);// сохраняем в "all_id_voted_posts" все post_id через пробел
			//alert(localStorage.getItem("post"+post_id)+'  '+localStorage.getItem("all_id_voted_posts"));
			return;
		}
	}
	return;
}

all_id_voted_posts = localStorage.getItem("all_id_voted_posts");
array_of_post_id = all_id_voted_posts.split(" ");//расщепляем all_id_voted_posts в массив
all_id_voted_posts='';//alert(array_of_post_id);
for (var i = 1; i < array_of_post_id.length; i++) {//пробегаем весь массив кроме нулевого элемента(там null)

	if (Date.now()-localStorage.getItem("post"+array_of_post_id[i]) > 7*86400000) //если проголосовано более 7 дней назад. 86400000 - это количество миллисекунд в сутках
		localStorage.removeItem("post"+array_of_post_id[i]);//то удаляем из localStorage
	else{ 
		all_id_voted_posts += " "+array_of_post_id[i];//если проголосовано менее 7 дней назад, то сохраняем все post_id через пробел в localStorage.setItem("all_id_voted_posts"
		if(document.getElementById('strelka_vverh_posts'+array_of_post_id[i]))
			remove_arrows_posts(array_of_post_id[i]);//убираем стрелки у комментариев проголосованных менее 7 дней назад
	}
}
localStorage.setItem("all_id_voted_posts",all_id_voted_posts);
//localStorage.clear();

function remove_arrows_posts(post_id){//alert(post_id);
	document.getElementById('strelka_vverh_posts'+post_id).innerHTML = '';//убираем стрелки
	document.getElementById('strelka_vniz_posts'+post_id).innerHTML = '';
}
 </script>
	<?php
}












function create_fields_in_database_posts_table() {//добавляем в таблицу comments поля pluses и minuses
	$db = mysqli_connect("127.0.0.1", "db_user", "db_user_password", "db_name");
	

	if (!$db) {
	    echo "Ошибка: Невозможно установить соединение с MySQL.<br>" . PHP_EOL;
	    echo "Код ошибки errno: " . mysqli_connect_errno() ."<br>". PHP_EOL;
	    echo "Текст ошибки error: " . mysqli_connect_error() ."<br>". PHP_EOL;
	    exit;
	}

	global $wpdb;
	$wp_table = $wpdb->prefix . "posts";
	$chkcol = mysqli_query($db, "SELECT * FROM `$wp_table` LIMIT 1");
	$mycol = mysqli_fetch_array($chkcol);
	if(!isset($mycol['pluses']))
		$result = mysqli_query($db, "ALTER TABLE $wp_table ADD pluses smallint UNSIGNED NOT NULL DEFAULT 0") or die(mysqli_error($db));//smallint - 2 байта
	if(!isset($mycol['minuses']))
		$result = mysqli_query($db, "ALTER TABLE $wp_table ADD minuses smallint UNSIGNED NOT NULL DEFAULT 0") or die(mysqli_error($db));//добавляем в таблицу comments поля pluses и minuses
	

}
register_activation_hook( __FILE__, 'create_fields_in_database_posts_table' );
?>
